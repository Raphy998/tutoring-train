Copy these 5 .jar files to "glassfish\modules" in your glassfish installation folder.
This will replace 5 existing files and update Jackson to version 2.9.2 (required to run this webservice)